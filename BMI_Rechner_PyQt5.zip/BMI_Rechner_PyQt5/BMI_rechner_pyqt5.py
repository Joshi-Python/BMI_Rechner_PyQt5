import sys
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QLineEdit, QPushButton, QLabel

class Myapp(QWidget):
    def __init__(self):
        super().__init__()
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle("BMI-Rechner")
        self.resize(500, 250)


        # Layout
        layout = QVBoxLayout()

        # Label (Text im Fenster)
        label = QLabel("Willkommen beim BMI-Rechner.\nBitte Gewicht (kg) und Größe (cm) eingeben:")
        layout.addWidget(label)

        # Eingabefelder
        self.eingabe_gewicht = QLineEdit()
        self.eingabe_gewicht.setPlaceholderText("Gewicht in kg")
        layout.addWidget(self.eingabe_gewicht)

        self.eingabe_groesse = QLineEdit()
        self.eingabe_groesse.setPlaceholderText("Größe in cm")
        layout.addWidget(self.eingabe_groesse)

        # Label für die Ausgabe
        self.ausgabe = QLabel("")
        layout.addWidget(self.ausgabe)

        # Button
        button = QPushButton("Weiter")
        layout.addWidget(button)
        button.clicked.connect(self.update_text)  # <-- hier auf die Instanz-Methode verbinden

        # Fenster anzeigen
        self.setLayout(layout)
        self.show()

    def update_text(self):
        try:
            # Komma in Punkt umwandeln, Leerzeichen entfernen
            g_text = self.eingabe_gewicht.text().strip().replace(',', '.')
            h_text = self.eingabe_groesse.text().strip().replace(',', '.')

            gewicht = float(g_text)        # kg
            groesse_cm = float(h_text)     # cm
            groesse_m = groesse_cm / 100.0 # m

            if gewicht <= 0 or groesse_m <= 0:
                self.ausgabe.setText("Bitte sinnvolle Werte > 0 eingeben.")
                return

            bmi = gewicht / (groesse_m ** 2)
            self.ausgabe.setText(f"Dein BMI ist: {bmi:.2f}")
        except ValueError:
            self.ausgabe.setText("Bitte gültige Zahlen eingeben.")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = Myapp()
    sys.exit(app.exec_())









